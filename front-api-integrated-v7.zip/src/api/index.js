import axios from 'axios';

// 기본 URL 설정 (백엔드 서버)
const api = axios.create({
  baseURL: 'http://localhost:8080',
});

// 요청 인터셉터: 로컬 스토리지에 저장된 학생 ID를 헤더에 자동 첨부
api.interceptors.request.use((config) => {
  const studentId = localStorage.getItem('selectedStudentId');
  if (studentId) {
    config.headers['X-Student-Id'] = studentId;
  }
  return config;
});

// 응답 인터셉터: 백엔드 에러 공통 처리
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.data) {
      const { code, message } = error.response.data;
      
      switch (code) {
        case 'MISSING_STUDENT_ID':
          alert('로그인이 필요합니다. 다시 로그인해 주세요.');
          window.location.href = '/';
          break;
        case 'STUDENT_NOT_FOUND':
          alert('존재하지 않는 학생입니다.');
          break;
        case 'COURSE_NOT_FOUND':
          alert('강의 정보를 찾을 수 없습니다.');
          break;
        case 'INVALID_PARAMETER':
          alert('요청 파라미터가 올바르지 않습니다.');
          break;
        default:
          alert(message || '오류가 발생했습니다.');
      }
    }
    return Promise.reject(error);
  }
);

export default api;
