<template>
  <div>
    <input v-model="keyword" placeholder="과목명 검색" />
    <button @click="fetchCourses">검색</button>
    
    <ul>
      <li v-for="course in courses" :key="course.offeringId">
        {{ course.courseName }} - {{ course.professor }} (여석: {{ course.remainingSeats }})
        <span>교환 희망자: {{ course.exchange.wantCount }}, 교환 보유자: {{ course.exchange.offerCount }}</span>
      </li>
    </ul>
  </div>
</template>

<script>
import api from '@/api';

export default {
  data() {
    return {
      keyword: '',
      courses: []
    };
  },
  methods: {
    async fetchCourses() {
      try {
        // API 연동: GET /api/courses
        const response = await api.get('/api/courses', {
          params: { keyword: this.keyword }
        });
        this.courses = response.data.content; // PageResponse 구조에 맞춤
      } catch (error) {
        console.error('강의 검색 실패', error);
      }
    }
  },
  mounted() {
    // 초기 로드시 전체 강의 목록을 렌더링
    this.fetchCourses();
  }
}
</script>
