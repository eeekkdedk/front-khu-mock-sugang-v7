<template>
  <div class="home">
    <h1>수강신청 맞교환 플랫폼</h1>
    <div>
      <label>학생 선택(로그인): </label>
      <select v-model="selectedStudentId">
        <option disabled value="">학생을 선택하세요</option>
        <option v-for="student in students" :key="student.studentId" :value="student.studentId">
          {{ student.nickname }} ({{ student.department }} {{ student.year }}학년)
        </option>
      </select>
    </div>
    <button @click="handleLogin">로그인</button>
  </div>
</template>

<script>
import api from '@/api';

export default {
  data() {
    return {
      selectedStudentId: '',
      students: [] // 서버에서 받아올 학생 목록
    };
  },
  async mounted() {
    // 앱 로드 시 학생 목록 조회 API 호출
    try {
      // API 연동: GET /api/students
      const response = await api.get('/api/students');
      this.students = response.data; // 예: [{ studentId: 1, nickname: '...', ... }]
    } catch (error) {
      console.error('학생 목록 로드 실패', error);
      // 데모용 하드코딩 데이터 세팅 (서버가 닫혀있을 때를 대비)
      this.students = [
        { studentId: '20240001', nickname: '익명1', department: '컴퓨터공학과', year: 2 },
        { studentId: '20240002', nickname: '익명2', department: '경영학과', year: 3 }
      ];
    }
  },
  methods: {
    handleLogin() {
      if (!this.selectedStudentId) {
        alert("학생을 선택해주세요.");
        return;
      }
      // 로컬 스토리지에 저장하여 이후 api 요청시 헤더에 포함되도록 함
      localStorage.setItem('selectedStudentId', this.selectedStudentId);
      alert('로그인 성공!');
      this.$router.push('/course');
    }
  }
}
</script>
