<template>
  <header>
    <h2>수강신청</h2>
    <div v-if="studentInfo">
      <p>환영합니다, {{ studentInfo.nickname }}님!</p>
      <p>신청 학점: {{ studentInfo.currentCredits }} / {{ studentInfo.maxCredits }}</p>
    </div>
  </header>
</template>

<script>
import api from '@/api';

export default {
  data() {
    return {
      studentInfo: null
    };
  },
  async mounted() {
    try {
      // API 연동: GET /api/students/me
      const response = await api.get('/api/students/me');
      this.studentInfo = response.data;
    } catch (error) {
      console.error('내 프로필 로드 실패', error);
      // 데모용 데이터
      this.studentInfo = { nickname: '익명(데모)', currentCredits: 12, maxCredits: 21 };
    }
  }
}
</script>
